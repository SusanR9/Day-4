import React, { Component } from "react";

class Timer extends Component {

  constructor() {
    super();
    this.state = {
      currentTime: new Date().toLocaleTimeString()
    };
  }

  componentDidMount() {
    setInterval(() => {
      this.setState({
        currentTime: new Date().toLocaleTimeString()
      });
    }, 1000);
  }

  render() {
    return (
      <div>
        <h2>Current Time:</h2>
        <h3>{this.state.currentTime}</h3>
      </div>
    );
  }
}

export default Timer;