import logo from './logo.svg';
import './App.css';

import Timer from "./Timer";

function App() {
  return (
    <div>
      <h1>Class Component Timer</h1>

      <Timer />

    </div>
  );
}

export default App;

