import React, { Component } from "react";

class ClickCounter extends Component {

  constructor() {
    super();
    this.state = {
      count: 0
    };
  }

  incrementCounter = () => {
    this.setState({
      count: this.state.count + 1
    });
  };

  render() {
    return (
      <div>
        <h2>Counter: {this.state.count}</h2>
        <button onClick={this.incrementCounter}>
          Click Me
        </button>
      </div>
    );
  }
}

export default ClickCounter;