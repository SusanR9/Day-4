import logo from './logo.svg';
import './App.css';


import ClickCounter from "./ClickCounter";

function App() {
  return (
    <div>
      <h1>Click Counter Example</h1>

      <ClickCounter />

    </div>
  );
}

export default App;

