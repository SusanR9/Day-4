import logo from './logo.svg';
import './App.css';

import ShowHide from "./ShowHide";

function App() {
  return (
    <div>
      <h1>Show / Hide Text Example</h1>

      <ShowHide />

    </div>
  );
}

export default App;

