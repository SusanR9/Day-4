import React from "react";

function ShowHide() {

  const showText = true;   // boolean variable

  return (
    <div>
      {showText && <h2>Hello, World!</h2>}
    </div>
  );
}

export default ShowHide;