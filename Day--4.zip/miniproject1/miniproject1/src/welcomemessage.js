import React from 'react';
function WelcomeMessage() {

  const style = {
    color: "white",
    backgroundColor: "blue",
    padding: "15px",
    textAlign: "center",
    borderRadius: "8px"
  };

  return (
    <div style={style}>
      <h1>Welcome to React Learning!</h1>
    </div>
  );
}

export default WelcomeMessage;
    