import logo from './logo.svg';
import './App.css';
/*function App() {
  return (
        <><><h1>Welcome to React!</h1><p>Learning React is fun!</p></><h2>First Component</h2><h2>Second Component</h2><h2>Third Component</h2></>
  );
}
export default App;
*/
/*import React, { Component } from "react";

class BasicClass extends Component {
  render() {
    return <h1>This is a Class Component</h1>;
  }
}
export default BasicClass;*/
/*import React, { Component } from "react";
class HelloClass extends Component {
  render() {
    return <h2>Hello from Class Component!</h2>;
  }
}
export default HelloClass;*/
/*import React, { Component } from "react";
class Counter extends Component {

  constructor() {
    super();
    this.state = {
      count: 0
    };
  }

  render() {
    return <h2>Counter: {this.state.count}</h2>;
  }
}

export default Counter;*/

/*import React, { Component } from "react";
class CounterButton extends Component {

  constructor() {
    super();
    this.state = { count: 0 };
  }

  increment = () => {
    this.setState({ count: this.state.count + 1 });
  };

  render() {
    return (
      <div>
        <h2>Counter: {this.state.count}</h2>
        <button onClick={this.increment}>Increase</button>
      </div>
    );
  }
}
export default CounterButton;*/

/*import React from "react";
function StyledMessage() {

  const style = {
    color: "blue",
    fontSize: "24px"
  };

  return <h2 style={style}>Styled Functional Component</h2>;
}
export default StyledMessage;*/

/*import React, { Component } from "react";
class StyledClass extends Component {
  render() {
    return <h2 className="title">Styled using CSS</h2>;
  }
}
export default StyledClass;*/

/*import React from "react";
function ConditionalMessage() {

  const show = true;

  return (
    <div>
      {show && <h2>React is Cool!</h2>}
    </div>
  );
}
export default ConditionalMessage;*/

/*import React from "react";
function Child() {
  return <p>This is Child Component</p>;
}

function Parent() {
  return (
    <div>
      <h2>Parent Component</h2>
      <Child />
    </div>
  );
}
export default Parent;*/

import React, { Component } from "react";
class LifeCycleExample extends Component {

  componentDidMount() {
    console.log("Component Mounted!");
  }

  render() {
    return <h2>Check console for lifecycle message</h2>;
  }
}
export default LifeCycleExample;